#ifdef USE_SYSTEM_ZXINGCPP
#error Your system zxing-cpp was not built with ZXING_EXPERIMENTAL_API enabled, fix that or use zxing-cpp bundled with MuPDF.
#endif
