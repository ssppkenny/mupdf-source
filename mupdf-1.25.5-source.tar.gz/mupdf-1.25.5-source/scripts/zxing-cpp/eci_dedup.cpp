#include "../../thirdparty/zxing-cpp/core/src/ECI.cpp"
